package edu.uic.SimFrame;

import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.JPanel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.BorderLayout;
import javax.swing.JList;
import javax.swing.border.MatteBorder;

import edu.uic.subparts.SimApp;
import edu.uic.subparts.SimClient;
import edu.uic.subparts.SimDevice;
import edu.uic.subparts.SimServer;
import edu.uic.subparts.SimSwitch;

import java.awt.Color;
import java.awt.Canvas;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.List;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JInternalFrame;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

public class frameWork {

	int i = 0, j = 0, k = 0, length = 0;
	ArrayList<JLabel> switches = new ArrayList<JLabel>();
	ArrayList<JLabel> clients = new ArrayList<JLabel>();
	ArrayList<JLabel> servers = new ArrayList<JLabel>();

	ArrayList<Integer> switches_added = new ArrayList<>();
	ArrayList<Integer> servers_added = new ArrayList<>();
	ArrayList<Integer> clients_added = new ArrayList<>();

	SimApp[] appList = new SimApp[10];
	String[] appNameList = new String[10];
	SimSwitch[] switchArray = new SimSwitch[10];

	JLabel lastSwitch;
	JLabel lastClient;
	JLabel lastServer;

	JLabel switch_n;
	JLabel client_n;
	JLabel server_n;

	JPanel panel_server = new JPanel();
	JPanel panel_switch = new JPanel();
	JPanel panel_client = new JPanel();

	HashMap<String, String> applicationMap;
	String name;

	private JFrame frame;

	private long macIterator = 0;
	private int switchIndex = 0;
	private SimClient[] clientArray = new SimClient[10];
	private int clientIndex = 0;
	private SimServer[] serverArray = new SimServer[10];
	private int serverIndex = 0;
	private long[][] macIPmapper = new long[10][2];
	private int macIPiterator = 0;
	private int ipIterator = 0;
	private long[][] connectionArray = new long[10][2];
	private int connectionIterator = 0;
	private String[][] bestRoute = new String[10][2];
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frameWork window = new frameWork();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frameWork() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1133, 594);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		panel_server.setBounds(261, 6, 77, 538);
		frame.getContentPane().add(panel_server);

		panel_switch.setBounds(381, 6, 151, 538);
		frame.getContentPane().add(panel_switch);

		panel_client.setBounds(591, 6, 100, 538);
		frame.getContentPane().add(panel_client);

		List list_servers = new List();
		list_servers.setBounds(827, 51, 137, 132);
		frame.getContentPane().add(list_servers);
		String[] serverArr = new String[10];

		List list_switches = new List();
		String[] switchArr = new String[10];

		List list_1 = new List();
		list_1.setBounds(970, 51, 137, 132);
		frame.getContentPane().add(list_1);

		List list_2 = new List();
		list_2.setBounds(970, 224, 137, 132);
		frame.getContentPane().add(list_2);

		List list_clients = new List();
		list_clients.setBounds(827, 224, 137, 132);
		frame.getContentPane().add(list_clients);

		String[] clientArr = new String[10];

		JLabel lblApplicationsRunning = new JLabel("Servers");
		lblApplicationsRunning.setBounds(827, 28, 93, 29);
		frame.getContentPane().add(lblApplicationsRunning);

		JLabel lblServerApplications = new JLabel("Server Applications");
		lblServerApplications.setBounds(970, 28, 117, 29);
		frame.getContentPane().add(lblServerApplications);

		JLabel lblClients = new JLabel("Clients");
		lblClients.setBounds(827, 203, 93, 29);
		frame.getContentPane().add(lblClients);

		JLabel lblClientApplications = new JLabel("Client Applications");
		lblClientApplications.setBounds(970, 203, 117, 29);
		frame.getContentPane().add(lblClientApplications);

		JPanel panel = new JPanel();
		panel.setBounds(0, 6, 228, 538);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		List list_3 = new List();
		list_3.setMultipleSelections(false);
		list_3.add("Application 1");
		list_3.add("Application 2");
		list_3.add("Application 3");
		list_3.add("Application 4");
		list_3.add("Application 5");
		list_3.add("Application 6");
		list_3.setBounds(13, 202, 138, 92);
		panel.add(list_3);
		
		JButton btnAddSwitch = new JButton("Add Switch");
		btnAddSwitch.setBounds(13, 5, 129, 23);
		panel.add(btnAddSwitch);
		btnAddSwitch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switches_added.add(i);
				name = "Switch " + k;
				switch_n = new JLabel("");

				list_switches.add(name);
				switchArr[k] = name;

				ImageIcon imageIcon = new ImageIcon("images/switch.png");

				switch_n.setIcon(imageIcon);
				switches.add(switch_n);
				SimSwitch switchCreate = new SimSwitch();
				
				switchArray[k] = switchCreate;
				switchArray[k].setMacAddress(macIterator);
				
				switch_n.setText("MAC:"+"128.128.0."+switchArray[k].getMacAddress());
				switch_n.setHorizontalTextPosition(JLabel.CENTER);
				switch_n.setVerticalTextPosition(JLabel.BOTTOM);
				macIterator++;
				
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						panel_switch.add(switch_n);
						panel_switch.validate();
						// panel_switch.repaint();
					}
				});

				lastSwitch = switch_n;
				k++;
			}
		});

		JButton btnAddClient = new JButton("Add Client");
		btnAddClient.setBounds(13, 55, 129, 23);
		panel.add(btnAddClient);
		btnAddClient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clients_added.add(i);
				if (switches.size() == 0) {
					JOptionPane.showMessageDialog(frame, "Switch doesn't exist. Please add a switch first", "Message",
							2);
				} else {
					name = "Client " + j;
					client_n = new JLabel("");

					ImageIcon imageIcon = new ImageIcon("images/client.png");
					client_n.setIcon(imageIcon);
					clients.add(client_n);
					list_clients.add(name);
					clientArr[j] = name;
					
					SimClient clientCreate = new SimClient();
					
					clientArray[j] = clientCreate;
					clientArray[j].setMacAddress(macIterator);
					clientArray[j].setIpAddress(ipIterator);
					

					
					client_n.setText("<html>" + "MAC:" +"128.128.0."+clientArray[j].getMacAddress()+ "<br>" + "IP: 192.0.0."+ clientArray[j].getIpAddress()+"</html>");
					client_n.setHorizontalTextPosition(JLabel.CENTER);
					client_n.setVerticalTextPosition(JLabel.BOTTOM);
					
					macIPmapper[macIPiterator][0] = macIterator;
					macIPmapper[macIPiterator][1] = ipIterator;
				//	System.out.println(macIPmapper[macIPiterator][0]);
					macIterator++;
					macIPiterator++;
					ipIterator++;
					
					// panel_switch.getGraphics().drawLine((client_n.getX()+150), (client_n.getY()),
					// (switch_n.getX()+10), (switch_n.getY()+10));
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							panel_client.add(client_n);
							panel_client.validate();
							panel_client.repaint();
						}
					});

					lastClient = client_n;
					j++;

					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							// panel_switch.getGraphics().drawLine((client_n.getX() + 150),
							// (client_n.getY()),
							// (switch_n.getX() + 10), (switch_n.getY() + 10));
						}
					});
				}
			}
		});

		JButton btnAddServer = new JButton("Add Server");
		btnAddServer.setBounds(13, 31, 129, 23);
		panel.add(btnAddServer);
		btnAddServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				servers_added.add(i);
				if (switches.size() == 0) {
					JOptionPane.showMessageDialog(frame, "Switch doesn't exist. Please add a switch first", "Message",
							2);
				} else {
					name = "Server " + i;
					server_n = new JLabel("");
					list_servers.add(name);
					serverArr[i] = name;

					ImageIcon imageIcon = new ImageIcon("images/server.png");
					server_n.setIcon(imageIcon);
					servers.add(server_n);
					
					SimServer serverCreate = new SimServer();
					
					serverArray[i] = serverCreate;
					serverArray[i].setMacAddress(macIterator);
					serverArray[i].setIpAddress(ipIterator);
					

					server_n.setText("<html>"+"MAC:" +"128.128.0."+serverArray[i].getMacAddress()+"<br>" + "IP: 192.0.0."+ serverArray[i].getIpAddress()+"</html>");
					server_n.setHorizontalTextPosition(JLabel.CENTER);
					server_n.setVerticalTextPosition(JLabel.BOTTOM);
					
					
					macIPmapper[macIPiterator][0] = macIterator;
					macIPmapper[macIPiterator][1] = ipIterator;

					macIPiterator++;
					ipIterator++;					
					macIterator++;
					server_n.setFont(server_n.getFont().deriveFont(8.0f));


					
					
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							panel_server.add(server_n);
							panel_server.validate();
							// panel_server.repaint();
						}
					});

					lastServer = server_n;
					i++;
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							//panel_switch.getGraphics().drawLine((server_n.getX() - 20), (server_n.getY()),
									//(switch_n.getX()), (switch_n.getY()));

						}
					});
				}
			}
		});

		JButton btnAddApplications = new JButton("Add Applications");
		btnAddApplications.setBounds(13, 325, 131, 23);
		panel.add(btnAddApplications);

		for (int i = 1; i < 6; i++) {

			String applicationName = "Application " + i;
			SimApp app = new SimApp(applicationName);

			System.out.println(applicationName);
			appNameList[i - 1] = applicationName;
		}

		// JComboBox<String> appList = new JComboBox<>(appNameList);
		// panel.add(appList);
		// String selectedApp = (String) appList.getSelectedItem();
		// System.out.println("You seleted the app: " + selectedApp);

		btnAddApplications.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			/*	String[] clientServerList = clients.toArray(new String[20]);
				System.out.println(clientServerList);
				String clientSelect = (String) JOptionPane.showInputDialog(null,
						"Choose an Client to run selected App on", "Add Application", JOptionPane.QUESTION_MESSAGE,
						null, clientServerList, // Array of choices
						null); // Initial choice
				System.out.println(clientSelect);*/
				
				int serverSize = list_servers.getRows();
				Random random = new Random();
				int randomNumber = random.nextInt(serverSize - 0) + 0;
				
				String selected_app = list_3.getSelectedItem().toString();
				System.out.println(selected_app);
				String selected_client = list_clients.getSelectedItem().toString(); 
				System.out.println(selected_client);
				applicationMap = new HashMap<String,String>();
				applicationMap.put(selected_client, selected_app);
				list_1.add(applicationMap.get(selected_client));
				list_2.add(applicationMap.get(selected_client));
				System.out.println(applicationMap.get(selected_client));
				JOptionPane.showMessageDialog(frame, selected_app + " is running on Server" + randomNumber, "Message",2);

			}

		});

		JButton btnDeleswitteCh = new JButton("Delete Switch");
		btnDeleswitteCh.setBounds(13, 117, 129, 23);
		panel.add(btnDeleswitteCh);

		JButton btnDeleteClient = new JButton("Delete Client");
		btnDeleteClient.setBounds(13, 139, 129, 23);
		btnDeleteClient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (!clients.isEmpty()) {

					panel_client.remove(clients.size() - 1);
					clients.remove(clients.size() - 1);
					panel_client.validate();
					panel_client.repaint();

					list_clients.remove(list_clients.getItemCount() - 1);
					clientArr[j - 1] = null;
					j--;

					if (j < 0) {
						j = 0;
					}
				}
			}
		});
		panel.add(btnDeleteClient);

		JButton btnDeleteServer = new JButton("Delete Server");
		btnDeleteServer.setBounds(13, 161, 129, 23);
		panel.add(btnDeleteServer);
		
		JButton btngetRoutes = new JButton("Configure Routes");
		btngetRoutes.setBounds(13, 413, 129, 23);
		panel.add(btngetRoutes);
		btngetRoutes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				getBestRoutes();
			}
			});
		
		
		
		
		

		JButton btnNewButton = new JButton("Add connection");
		btnNewButton.setBounds(13, 369, 129, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				showConnectionDialog(clientArr, switchArr, serverArr);

			}
		});
		panel.add(btnNewButton);
		

		Component verticalStrut = Box.createVerticalStrut(20);
		verticalStrut.setBounds(227, 11, 12, 538);
		frame.getContentPane().add(verticalStrut);

		btnDeleteServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (!servers.isEmpty()) {

					panel_server.remove(servers.size() - 1);
					servers.remove(servers.size() - 1);
					panel_server.validate();
					panel_server.repaint();

					list_servers.remove(list_servers.getItemCount() - 1);
					serverArr[i - 1] = null;

					i--;
					if (i < 0) {
						i = 0;
					}
				}
			}
		});
		btnDeleswitteCh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (!switches.isEmpty()) {

					panel_switch.remove(switches.size() - 1);
					switches.remove(switches.size() - 1);
					panel_switch.validate();
					panel_switch.repaint();

					list_switches.remove(list_servers.getItemCount() - 1);
					switchArr[k - 1] = null;

					k--;
					if (k < 0) {
						k = 0;
					}
				}
			}
		});

	}

	private void addConnection(JLabel from, JLabel to) {
		frame.getGraphics().drawLine(from.getX(), from.getY(), to.getX(), to.getY());
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}

			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}

			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}

		
	

	public void showConnectionDialog(String[] client_list, String[] switch_list, String[] server_list) {

		JPanel panel = new JPanel(new GridLayout(0, 1));
		
		String[] combinedArr = new String[30];
		
		int jloop = 0;
		for(int iloop = 0; iloop < 10; iloop ++) {
			if(client_list[iloop] != null && client_list[iloop] != "") {
				combinedArr[jloop++] = client_list[iloop];
			}
		}
		for(int iloop = 0; iloop < 10; iloop ++) {
			if(switch_list[iloop] != null && switch_list[iloop] != "") {
				combinedArr[jloop++] = switch_list[iloop];
			}
		}
		for(int iloop = 0; iloop < 10; iloop ++) {
			if(server_list[iloop] != null && server_list[iloop] != "") {
				combinedArr[jloop++] = server_list[iloop];
			}
		}
		
		JComboBox<String> combo1 = new JComboBox<>(combinedArr);
		panel.add(new JLabel("Point 1:"));
		panel.add(combo1);

		JComboBox<String> combo2 = new JComboBox<>(switch_list);
		panel.add(new JLabel("Point 2:"));
		panel.add(combo2);

		int result = JOptionPane.showConfirmDialog(null, panel, "Add Connection", JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.PLAIN_MESSAGE);
		String[] sep = combo1.getSelectedItem().toString().split(" ");

		if (result == JOptionPane.OK_OPTION) {
			if(combo1.getSelectedItem().toString().contains("Client")) {
				panel_switch.getGraphics().drawLine((clients.get(Integer.parseInt(sep[1])).getX() + 150),
						(clients.get(Integer.parseInt(sep[1])).getY()),
						(switches.get(combo2.getSelectedIndex()).getX() + 10),
						(switches.get(combo2.getSelectedIndex()).getY() + 10));

				String selected = (String) combo1.getSelectedItem();
				String selectedS2 = (String) combo2.getSelectedItem();
				
				System.out.println(selected);
				System.out.println(selected.substring(selected.length() - 1));
				
				int selected1 = Integer.parseInt(selected.substring(selected.length() - 1));
				int selected2 = Integer.parseInt(selectedS2.substring(selectedS2.length() - 1));
							
				
				connectionArray[connectionIterator][0] = clientArray[selected1].getMacAddress();
				connectionArray[connectionIterator][1] = switchArray[selected2].getMacAddress();
				
				System.out.println("connection 1 MAC "+connectionArray[connectionIterator][0]);
				System.out.println("Connection 2 MAC "+connectionArray[connectionIterator][1]);
				
				connectionIterator++;
			}
			else if(combo1.getSelectedItem().toString().contains("Server")) {
				panel_switch.getGraphics().drawLine((servers.get(Integer.parseInt(sep[1])).getX()-150),
						(servers.get(Integer.parseInt(sep[1])).getY()),
						(switches.get(combo2.getSelectedIndex()).getX() + 10),
						(switches.get(combo2.getSelectedIndex()).getY() + 10));
				
				
				String selected = (String) combo1.getSelectedItem();
				String selectedS2 = (String) combo2.getSelectedItem();
				
				System.out.println(selected);
				System.out.println(selected.substring(selected.length() - 1));
				
				int selected1 = Integer.parseInt(selected.substring(selected.length() - 1));
				int selected2 = Integer.parseInt(selectedS2.substring(selectedS2.length() - 1));
				
								
				connectionArray[connectionIterator][0] = serverArray[selected1].getMacAddress();
				connectionArray[connectionIterator][1] = switchArray[selected2].getMacAddress();

				System.out.println("connection 1 MAC "+connectionArray[connectionIterator][0]);
				System.out.println("Connection 2 MAC "+connectionArray[connectionIterator][1]);
				
				
				connectionIterator++;
				
				
			}
			else if(combo1.getSelectedItem().toString().contains("Switch")) {
				panel_switch.getGraphics().drawLine((switches.get(Integer.parseInt(sep[1])).getX() + 150),
						(switches.get(Integer.parseInt(sep[1])).getY()),
						(switches.get(combo2.getSelectedIndex()).getX() + 10),
						(switches.get(combo2.getSelectedIndex()).getY() + 10));
				System.out.println("Combo 1 index" + combo1.getSelectedIndex());
				String selected = (String) combo1.getSelectedItem();
				String selectedS2 = (String) combo2.getSelectedItem();
				
				System.out.println(selected);
				System.out.println(selected.substring(selected.length() - 1));
				
				int selected1 = Integer.parseInt(selected.substring(selected.length() - 1));
				int selected2 = Integer.parseInt(selectedS2.substring(selectedS2.length() - 1));
				
				connectionArray[connectionIterator][0] = switchArray[selected1].getMacAddress();
				connectionArray[connectionIterator][1] = switchArray[selected2].getMacAddress();
				
				System.out.println("connection 1 MAC "+connectionArray[connectionIterator][0]);
				System.out.println("Connection 2 MAC "+connectionArray[connectionIterator][1]);
				connectionIterator++;				
				
			}
			System.out.println(Integer.parseInt(sep[1]) + " " + combo2.getSelectedIndex() + " ");
			
			System.out.println("combo 1" + combo1.getSelectedIndex());
			System.out.println("combo 2" + combo2.getSelectedIndex());
//setBestRoute(connectionArray);
			
		} else {
			System.out.println("Cancelled");
		}

		
	}

	public String[][] getBestRoutes() {
		
		long[][] reverseConnectionArray = new long[2][10];
		
		long[] firstLinks = new long[10];
		long[] secondLinks = new long[10];
	//find the clients
		for(int rows=0; rows< connectionArray.length; rows++){
			
		    for(int columns=0;columns < connectionArray[rows].length; columns++){
		    	
		     //  System.out.print(connectionArray[rows][columns] + "\t" );
		        firstLinks[rows] = connectionArray[rows][0];
		        secondLinks[rows]=connectionArray[rows][1];
		        

		        
		        System.out.println(reverseConnectionArray[1][0]+ "reverse array");
		        System.out.println(reverseConnectionArray[1][1]+ "reverse array");
		    }
		    
		    for(i=0; i<firstLinks.length; i++){
		    	
		    	for(int rows2=0;rows2 < secondLinks.length; rows2++){
		    	
	        if(firstLinks[i]==secondLinks[rows2]  ){
	        	System.out.println("Route Found");
	        	String route = connectionArray[rows2][0]+ "," + connectionArray[rows2][1]+"to"+ connectionArray[i][0]+ "," + connectionArray[i][1];
	      
	        System.out.println(route);
	        }}}
		    
		}

	
		
//		
		return bestRoute;
	}
	
	
	
	
	
	
}
