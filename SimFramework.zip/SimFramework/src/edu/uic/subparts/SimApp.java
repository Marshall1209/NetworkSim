package edu.uic.subparts;

import java.io.*;
import java.net.*;
import java.lang.instrument.*;


public class SimApp  {
	private DatagramSocket socket = null;
	private String name;
	private SimMessage Message;
	

	
public SimApp(String applicationName) {
		// TODO Auto-generated constructor stub
this.name = applicationName;
}



public void createAndListenSocket(SimMessage message) {
		try {
			socket = new DatagramSocket(9876);
			byte[] incomingData = new byte[1024];

	while (true) {
		DatagramPacket incomingPacket = new DatagramPacket(incomingData, incomingData.length);
		socket.receive(incomingPacket);
		byte[] data = incomingPacket.getData();
		ByteArrayInputStream in = new ByteArrayInputStream(data);
		ObjectInputStream is = new ObjectInputStream(in);
		try {
			
 message = (SimMessage) is.readObject();
long messageSize = ObjectSizeFetcher.getObjectSize(message);


System.out.println("SimMessage object received = "+message + " Size: " + messageSize);


		} 
			catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	InetAddress IPAddress = incomingPacket.getAddress();
		int port = incomingPacket.getPort();
String reply = "Thank you for the message";
		byte[] replyBytea = reply.getBytes();
DatagramPacket replyPacket = 	new DatagramPacket(replyBytea, replyBytea.length, IPAddress, port);
		
		socket.send(replyPacket);
		
		Thread.sleep(2000);
		System.exit(0);
}	} 
		catch (SocketException e) {
			e.printStackTrace();
		} 
		catch (IOException i) {
			i.printStackTrace();
		} 
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		}



public String getName() {
	return name;
}



public void setName(String name) {
	this.name = name;
}







}
