package edu.uic.subparts;

public class SimServer extends SimDevice{

}
