package edu.uic.subparts;

public class SimDevice {
	private long macAddress;
	private long ipAddress;
	public long getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(long macAddress) {
		this.macAddress = macAddress;
	}
	public long getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(long ipAddress) {
		this.ipAddress = ipAddress;
	}

	}

