package edu.uic.subparts;

public class SimMessage {

}
