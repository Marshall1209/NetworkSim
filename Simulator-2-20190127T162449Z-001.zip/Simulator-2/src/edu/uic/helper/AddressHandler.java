package edu.uic.helper;

public class AddressHandler {

	private static String constantMacAddress = "128.128.0";
	private static String constantIpAddress = "192.0.0";

	public static String getConstantMacAddress(long macAddress) {
		if(macAddress >= 255) {
			constantMacAddress = "128.128." + Integer.toString((Integer.parseInt(constantMacAddress.split(".")[2])+1));
		}
		return constantMacAddress;
	}

	public static String getConstantIpAddress(long ipAddress) {
		if(ipAddress >= 255) {
			constantIpAddress = "192.0." + Integer.toString((Integer.parseInt(constantIpAddress.split(".")[2])+1));
		}
		return constantIpAddress;
	}
}