package edu.uic.subparts;

import java.io.*;
import java.net.*;

public class SimApp {

	private DatagramSocket socket = null;
	private String name;
	private SimMessage message;

	public SimApp() {
	}


	public SimApp(String applicationName) 
	{
		this.name = applicationName;
	}

	/* this returns an array of packets and a sequence number will be plugged  
       in to reassemble the packets correctly at the destination which
       will be sent to the identified destination
    */
	public DatagramPacket createPackets(SimMessage message)
	{
		//ArrayList<SimPacket> packets = new ArrayList<SimPacket>();
		DatagramPacket incomingPacket = null;
		try
		{
			socket = new DatagramSocket(9876);
			byte[] incomingData = new byte[1024]; 
			incomingData = message.toString().getBytes();

			while(true)
			{
				incomingPacket = new DatagramPacket(incomingData,incomingData.length);
			}
			//This must be done for four applications
		}
		catch (SocketException e) {
			e.printStackTrace();
		} 

		return incomingPacket;
	}


	public void createAndListenSocket(SimMessage message) {
		try {
			socket = new DatagramSocket(9876);
			byte[] incomingData = new byte[1024]; 


			while (true) {
				DatagramPacket incomingPacket = new DatagramPacket(incomingData, incomingData.length);
				socket.receive(incomingPacket); 
				byte[] data = incomingPacket.getData();
				ByteArrayInputStream in = new ByteArrayInputStream(data);
				ObjectInputStream is = new ObjectInputStream(in);
				try {

					message = (SimMessage) is.readObject();
					long messageSize = ObjectSizeFetcher.getObjectSize(message);


					System.out.println("SimMessage object received = "+message + " Size: " + messageSize);


				} 
				catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				InetAddress IPAddress = incomingPacket.getAddress();
				int port = incomingPacket.getPort();
				String reply = "Thank you for the message";
				byte[] replyBytea = reply.getBytes();
				DatagramPacket replyPacket = 	new DatagramPacket(replyBytea, replyBytea.length, IPAddress, port);

				socket.send(replyPacket);

				Thread.sleep(2000);
				System.exit(0);
			}	} 
		catch (SocketException e) {
			e.printStackTrace();
		} 
		catch (IOException i) {
			i.printStackTrace();
		} 
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public SimMessage getMessage() {
		return message;
	}

	public void setMessage(SimMessage message) {
		this.message = message;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}