package edu.uic.subparts;

import edu.uic.helper.AddressHandler;

public class SimDevice {
	private long macAddress;
	private long ipAddress;
	
	private String macAddressFull;
	private String ipAddressFull;
	
	public String getMacAddressFull() {
		return macAddressFull;
	}

	public String getIpAddressFull() {
		return ipAddressFull;
	}

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(long macAddress) {
		this.macAddress = macAddress;
		this.macAddressFull = AddressHandler.getConstantMacAddress(macAddress) + macAddress;
	}

	public long getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(long ipAddress) {
		this.ipAddress = ipAddress;
		this.ipAddressFull = AddressHandler.getConstantIpAddress(ipAddress) + this.ipAddress;
	}
}
