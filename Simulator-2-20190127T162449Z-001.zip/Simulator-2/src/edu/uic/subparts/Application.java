package edu.uic.subparts;

public class Application {

	String a[] = {"Application 1", "Application 2", "Application 3", "Application 4", "Application 5"};


}
