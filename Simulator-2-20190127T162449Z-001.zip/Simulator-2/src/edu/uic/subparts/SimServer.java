package edu.uic.subparts;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class SimServer extends SimDevice {

	private DatagramSocket aSocket = null;
	
	public void acceptRequest()
	{
	try 
	{
		//int socket_no = Integer.valueOf(args[0]).intValue();
		aSocket = new DatagramSocket(9740);
		byte[] buffer = new byte[1000];
		while(true) 
		{
			DatagramPacket request = new DatagramPacket(buffer,
			buffer.length);
			aSocket.receive(request);
			DatagramPacket reply = new DatagramPacket(request.getData(),
			request.getLength(),request.getAddress(),
			request.getPort());
			aSocket.send(reply);
		}
	}
		catch (SocketException e) {
		System.out.println("Socket: " + e.getMessage());
		}
		catch (IOException e) {
		System.out.println("IO:" + e.getMessage());
		}
		finally {
		if (aSocket != null)
		aSocket.close();
		}
	}
}
