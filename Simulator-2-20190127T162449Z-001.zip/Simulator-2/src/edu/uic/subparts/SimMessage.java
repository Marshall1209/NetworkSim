package edu.uic.subparts;

import java.util.ArrayList;
import java.util.List;

public class SimMessage {

	private String source;
	private String destination;
	private SimApp application_name;
	private int message_size;

	private int numberOfPackets;
	private int applicationTime;
	private List<SimPacket> simPacket;

	public SimMessage(int numberOfPackets, int applicationTime) {
		this.numberOfPackets = numberOfPackets;
		this.applicationTime = applicationTime;
		simPacket = new ArrayList<>();
		this.createPackets();
	}

	private void createPackets() {
		for(int i = 0; i< numberOfPackets; i++) {
			SimPacket packet = new SimPacket();
			packet.setPacketTime(applicationTime/numberOfPackets);
			simPacket.add(packet);
		}
	}

	public List<SimPacket> getSimPacket() {
		return simPacket;
	}

	public void setSimPacket(List<SimPacket> simPacket) {
		this.simPacket = simPacket;
	}

	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public SimApp getApplication_name() {
		return application_name;
	}
	public void setApplication_name(SimApp application_name) {
		this.application_name = application_name;
	}
	public int getMessage_size() {
		return message_size;
	}
	public void setMessage_size(int message_size) {
		this.message_size = message_size;
	}

	public int getNumberOfPackets() {
		return numberOfPackets;
	}

	public void setNumberOfPackets(int numberOfPackets) {
		this.numberOfPackets = numberOfPackets;
	}

	public int getApplicationTime() {
		return applicationTime;
	}

	public void setApplicationTime(int applicationTime) {
		this.applicationTime = applicationTime;
	}
}