package edu.uic.subparts;


public class SimClient extends SimDevice {
		
	
}