package edu.uic.subparts;

public class SimPacket {

	private String source;
	private String destination;
	private SimApp application;
	private int sequence_number;
	private int packetTime;

	public int getPacketTime() {
		return packetTime;
	}
	public void setPacketTime(int packetTime) {
		this.packetTime = packetTime;
	}
	public int getSequence_number() {
		return sequence_number;
	}
	public void setSequence_number(int sequence_number) {
		this.sequence_number = sequence_number;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public SimApp getApplication() {
		return application;
	}
	public void setApplication(SimApp application) {
		this.application = application;
	}



}
