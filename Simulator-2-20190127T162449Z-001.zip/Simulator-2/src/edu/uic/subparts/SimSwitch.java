package edu.uic.subparts;

public class SimSwitch extends SimDevice {

}
